export interface Review {
  id: string;
  facility: string;
  hotel: string;
  rating: number;
  comments: string;
}
