package com.example.TMSBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TmsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
