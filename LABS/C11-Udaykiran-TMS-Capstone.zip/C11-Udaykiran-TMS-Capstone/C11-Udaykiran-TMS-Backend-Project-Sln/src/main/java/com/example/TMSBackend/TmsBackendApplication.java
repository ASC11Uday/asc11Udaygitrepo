package com.example.TMSBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TmsBackendApplication {

	public static void main(String[] args) {
		System.out.println("Just another Java App, not any more");
		SpringApplication.run(TmsBackendApplication.class, args);
	}

}
